package com.princess.playlist;
import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.pm.PackageManager;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.webkit.*;
import android.content.Intent;
import android.graphics.Color;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackParameters;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.MoreExecutors;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
 MediaController controller; WebView web;
 ValueCallback<Uri[]> fileCallback;
 private static final int FILE_REQUEST=102, AUDIO_PERMISSION=103;
 @Override public void onCreate(Bundle b){super.onCreate(b);
  getWindow().setStatusBarColor(Color.rgb(255,246,251));getWindow().setNavigationBarColor(Color.rgb(255,246,251));
  getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
  web=new WebView(this);setContentView(web);
  web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowContentAccess(true);
  web.addJavascriptInterface(new NativeBridge(),"PrincessAndroid");
  web.setWebViewClient(new WebViewClient());
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){
    if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;
    try{Intent intent=params.createIntent();intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("audio/*");intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(intent,FILE_REQUEST);return true;}
    catch(Exception e){fileCallback=null;return false;}
   }
  });
  web.loadUrl("file:///android_asset/index.html");
  SessionToken token=new SessionToken(this,new android.content.ComponentName(this,PlaybackService.class));
  ListenableFuture<MediaController> future=new MediaController.Builder(this,token).buildAsync();
  future.addListener(()->{try{controller=future.get();controller.addListener(new Player.Listener(){@Override public void onIsPlayingChanged(boolean playing){notifyPlayer();}@Override public void onMediaItemTransition(MediaItem item,int reason){notifyPlayer();}@Override public void onPlaybackStateChanged(int state){notifyPlayer();}});notifyPlayer();}catch(Exception ignored){}},MoreExecutors.directExecutor());
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(request==FILE_REQUEST&&fileCallback!=null){Uri[] values=null;
   if(result==RESULT_OK&&data!=null){if(data.getClipData()!=null){int n=data.getClipData().getItemCount();values=new Uri[n];for(int i=0;i<n;i++)values[i]=data.getClipData().getItemAt(i).getUri();}else if(data.getData()!=null)values=new Uri[]{data.getData()};}
   fileCallback.onReceiveValue(values);fileCallback=null;
  }
 }
 void notifyPlayer(){if(controller==null||web==null)return;String js="window.princessPlaybackState&&window.princessPlaybackState("+controller.getCurrentMediaItemIndex()+","+controller.isPlaying()+","+controller.getCurrentPosition()+","+controller.getDuration()+")";runOnUiThread(()->web.evaluateJavascript(js,null));}
 class NativeBridge {
  @JavascriptInterface public void setQueue(String json,int start){runOnUiThread(()->{if(controller==null)return;try{JSONArray arr=new JSONArray(json);java.util.ArrayList<MediaItem> items=new java.util.ArrayList<>();for(int i=0;i<arr.length();i++){JSONObject t=arr.getJSONObject(i);MediaMetadata m=new MediaMetadata.Builder().setTitle(t.optString("name")).setArtist(t.optString("artist")).build();items.add(new MediaItem.Builder().setUri(t.getString("url")).setMediaMetadata(m).build());}controller.setMediaItems(items,Math.max(0,Math.min(start,items.size()-1)),0);controller.prepare();controller.play();notifyPlayer();}catch(Exception ignored){}});}
  @JavascriptInterface public void playIndex(int index){runOnUiThread(()->{if(controller!=null&&index>=0&&index<controller.getMediaItemCount()){controller.seekToDefaultPosition(index);controller.play();notifyPlayer();}});}
  @JavascriptInterface public void play(){runOnUiThread(()->{if(controller!=null){controller.play();notifyPlayer();}});}
  @JavascriptInterface public void pause(){runOnUiThread(()->{if(controller!=null){controller.pause();notifyPlayer();}});}
  @JavascriptInterface public void seek(long millis){runOnUiThread(()->{if(controller!=null)controller.seekTo(Math.max(0,millis));});}
  @JavascriptInterface public void next(){runOnUiThread(()->{if(controller!=null){controller.seekToNextMediaItem();controller.play();}});}
  @JavascriptInterface public void previous(){runOnUiThread(()->{if(controller!=null){controller.seekToPreviousMediaItem();controller.play();}});}
  @JavascriptInterface public void setRepeat(int mode){runOnUiThread(()->{if(controller!=null)controller.setRepeatMode(mode==2?Player.REPEAT_MODE_ONE:mode==1?Player.REPEAT_MODE_ALL:Player.REPEAT_MODE_OFF);});}
  @JavascriptInterface public void setShuffle(boolean on){runOnUiThread(()->{if(controller!=null)controller.setShuffleModeEnabled(on);});}
  @JavascriptInterface public void setSpeed(float speed){runOnUiThread(()->{if(controller!=null)controller.setPlaybackParameters(new PlaybackParameters(Math.max(.5f,Math.min(2f,speed))));});}
  @JavascriptInterface public String getState(){if(controller==null)return "{}";try{return new JSONObject().put("index",controller.getCurrentMediaItemIndex()).put("playing",controller.isPlaying()).put("position",controller.getCurrentPosition()).put("duration",controller.getDuration()).toString();}catch(Exception e){return "{}";}}

  @JavascriptInterface public void requestLibrary(){runOnUiThread(()->{String permission=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;
   if(checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED)loadLibrary();else requestPermissions(new String[]{permission},AUDIO_PERMISSION);
  });}
 }
 @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){super.onRequestPermissionsResult(request,permissions,grants);
  if(request==AUDIO_PERMISSION&&grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)loadLibrary();
 }
 void loadLibrary(){new Thread(()->{JSONArray songs=new JSONArray();
  Uri collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
  String[] columns={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST};
  try(Cursor cursor=getContentResolver().query(collection,columns,MediaStore.Audio.Media.IS_MUSIC+"!=0",null,MediaStore.Audio.Media.TITLE+" COLLATE NOCASE ASC")){
   if(cursor!=null)while(cursor.moveToNext()){JSONObject song=new JSONObject();song.put("name",cursor.getString(1));song.put("artist",cursor.getString(2));song.put("url",ContentUris.withAppendedId(collection,cursor.getLong(0)).toString());songs.put(song);}
  }catch(Exception ignored){}
  String payload=JSONObject.quote(songs.toString());runOnUiThread(()->web.evaluateJavascript("window.princessNativeTracks&&window.princessNativeTracks("+payload+")",null));
 }).start();}
 @Override public void onBackPressed(){web.evaluateJavascript("(function(){if(!document.getElementById('playerPage').classList.contains('hidden')){document.getElementById('closePlayer').click();return true;}return false;})()",v->{if(!"true".equals(v))MainActivity.super.onBackPressed();});}
 @Override protected void onDestroy(){if(controller!=null)controller.release();if(fileCallback!=null)fileCallback.onReceiveValue(null);web.destroy();super.onDestroy();}
}
