package com.princess.playlist;
import android.content.Intent;
import android.net.Uri;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;

public class PlaybackService extends MediaSessionService {
 private ExoPlayer player; private MediaSession session;
 @Override public void onCreate(){super.onCreate();player=new ExoPlayer.Builder(this).build();player.setAudioAttributes(new androidx.media3.common.AudioAttributes.Builder().setUsage(androidx.media3.common.C.USAGE_MEDIA).setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC).build(),true);session=new MediaSession.Builder(this,player).build();}
 @Override public MediaSession onGetSession(MediaSession.ControllerInfo info){return session;}
 @Override public void onDestroy(){if(session!=null){session.release();session=null;}if(player!=null){player.release();player=null;}super.onDestroy();}
}
